package inventario.principal;

public class Aplicacion {

    public static void main(String[] args) {
        
        inventario inventario = new inventario();
        
        inventario.setVisible(true);
    }
}
