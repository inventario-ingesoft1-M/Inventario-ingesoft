/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package caja.pedidos.acciones;
import caja.pedidos.FechaPedidos;
import caja.gestionBD.ServicePedidos;
import javax.swing.JOptionPane;
import java.sql.ResultSet;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author pacolavado
 */
public class AccionesFechaPedidos {
    private FechaPedidos fechaPedidos;
    private ServicePedidos servicePedidos;
    DefaultTableModel tabla = new DefaultTableModel (new String[]{
            "Número pedido","Importe","Código cliente","Productos"
        },0);
    public AccionesFechaPedidos(FechaPedidos fechaPedidos){
        this.fechaPedidos=fechaPedidos;
        this.servicePedidos=new ServicePedidos();
        
    }
    public void mostrarPedidos(String dia, String mes, String anno){
        ResultSet r;
        String fila[]=new String[4];
        int numeroDia=0;
        int numeroMes=0;
        int numeroAnno=0;
        int numeroFilas=0;
        numeroFilas=tabla.getRowCount();
        while (numeroFilas>0){
            tabla.removeRow(numeroFilas-1);
            numeroFilas --;
        }
        try {
            numeroDia=Integer.parseInt(dia);
            numeroMes=Integer.parseInt(mes);
            numeroAnno=Integer.parseInt(anno);
        }catch (Exception e){
            JOptionPane.showMessageDialog(null,"La fecha introducida es incorrecta");
        }
       if (((numeroMes>=1) && (numeroMes<=12)) && ((numeroDia>=1) && (numeroDia<=31)) && ((numeroAnno>=1) && (numeroAnno<=3000))){
            if ((((numeroMes==4)||(numeroMes==6)||(numeroMes==9)||(numeroMes==11))&&(numeroDia<=30))||((numeroMes==2)
                    && (numeroDia<=28))||(numeroMes==1)||(numeroMes==3)||(numeroMes==5)||(numeroMes==7)||(numeroMes==8)||(numeroMes==10)){
                try {
                    r=servicePedidos.mostrarFechaPedidos(dia,mes,anno);
                    while (r.next()){
                        fila[0]=r.getString("NumeroPedido");
                        fila[1]=r.getString("Importe");
                        fila[2]=r.getString("NIF");
                        fila[3]=r.getString("Productos");
                        tabla.addRow(fila);
                        fechaPedidos.getTblFechaPedidos().setModel(tabla);
                        fechaPedidos.getPanelTabla().setViewportView(fechaPedidos.getTblFechaPedidos());
                    }
                }catch (Exception e){
                  System.out.println("no esta entrando porque se esta produciendo algun error");  
                }
            }
        }else {
            JOptionPane.showMessageDialog(null,"La fecha introducida es incorrecta");
        }
    }
}
