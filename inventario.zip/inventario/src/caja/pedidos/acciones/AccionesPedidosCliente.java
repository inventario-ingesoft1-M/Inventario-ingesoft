/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package caja.pedidos.acciones;
import caja.pedidos.PedidosCliente;
import caja.gestionBD.ServicePedidos;
import javax.swing.JOptionPane;
import java.sql.ResultSet;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author pacolavado
 */
public class AccionesPedidosCliente {
    private PedidosCliente pedidosCliente;
    private ServicePedidos servicePedidos;
    DefaultTableModel tabla = new DefaultTableModel (new String[]{
            "Número pedido","Fecha","Importe","Productos"
        },0);
    public AccionesPedidosCliente(PedidosCliente pedidosCliente){
        this.pedidosCliente=pedidosCliente;
        this.servicePedidos=new ServicePedidos();
    }
    public void mostrarPedidos(String codigoCliente){
        ResultSet r;
        String fila[]=new String[4];
        int numeroFilas=0;
        numeroFilas=tabla.getRowCount();
        while (numeroFilas>0){
            tabla.removeRow(numeroFilas-1);
            numeroFilas --;
        }
        try {
            r=servicePedidos.mostrarPedidosCliente(codigoCliente);
            while (r.next()){
                fila[0]=r.getString("NumeroPedido");
                fila[1]=r.getString("Fecha");
                fila[2]=r.getString("Importe");
                fila[3]=r.getString("Productos");
                tabla.addRow(fila);
                pedidosCliente.getTblPedidosCliente().setModel(tabla);
                pedidosCliente.getPanelTabla().setViewportView(pedidosCliente.getTblPedidosCliente());
            }
        }catch (Exception e){
          System.out.println("no esta entrando porque se esta produciendo algun error");  
        }
    }
}
