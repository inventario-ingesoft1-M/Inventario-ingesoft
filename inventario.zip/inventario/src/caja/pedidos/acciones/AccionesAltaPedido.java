package caja.pedidos.acciones;
import caja.pedidos.AltaPedido;
import caja.gestionBD.ServicePedidos;
import caja.gestionBD.ServiceCliente;
import java.util.ArrayList;
import java.util.Vector;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class AccionesAltaPedido {
    //ATRIBUTOS
    private AltaPedido altaPedido;
    private ServicePedidos servicePedidos;
    private ServiceCliente serviceCliente;
    // En este ArrayList pedido se almacenan los datos del pedido (productos)
    private ArrayList pedido=new ArrayList();
    // clienteRegistrado es un flag que se pone a verdadero si se trata de un cliente
    // registrado, permitiendo así aplicar el descuento correspondiente
    private boolean clienteRegistrado;
    // total es un tipo de datos double que almacena el importe total del pedido
    private double total;
    String precioProducto;
    String NIF;
    String fecha;
    double precioproducto;
    int cantidadProductos=0;
    DefaultTableModel tabla = new DefaultTableModel (new String[]{
            "Producto","Precio"
        },0);
    //METODOS
    public AccionesAltaPedido(AltaPedido altaPedido){
        this.altaPedido= altaPedido;
        this.servicePedidos=new ServicePedidos();
        this.serviceCliente=new ServiceCliente();
        total=0;
    }    
    public boolean pedidoNoRegistrado(String dia,String mes, String anno){
        int numeroDia, numeroMes, numeroAnno;
        try {
            // Convertimos los datos de la fecha introducida de String a entero
            numeroDia=Integer.parseInt(dia);
            numeroMes=Integer.parseInt(mes);
            numeroAnno=Integer.parseInt(anno);
        }catch (Exception e){
            JOptionPane.showMessageDialog(null,"La fecha introducida es incorrecta");
            return false;
        }
        clienteRegistrado=false;
        // Comprobamos que la fecha sea correcta
        if (((numeroMes>=1) && (numeroMes<=12)) && ((numeroDia>=1) && (numeroDia<=31)) && ((numeroAnno>=1) && (numeroAnno<=3000))){
            if ((((numeroMes==4)||(numeroMes==6)||(numeroMes==9)||(numeroMes==11))&&(numeroDia<=30))||((numeroMes==2)
                    && (numeroDia<=28))||(numeroMes==1)||(numeroMes==3)||(numeroMes==5)||(numeroMes==7)||(numeroMes==8)||(numeroMes==10)){
                fecha=dia+"/"+mes+"/"+anno;
                // Al ser un cliente no registrado, se le asigna por defecto
                // el NIF 000000000
                NIF="No registrado";
            }return true;   // Los datos son correctos
        }else {
            JOptionPane.showMessageDialog(null,"La fecha introducida es incorrecta");
            return false;
        }
    }
    public boolean pedidoRegistrado(String dia,String mes,String anno, String codigoNIF){
        int numeroDia, numeroMes, numeroAnno;
        try {
            numeroDia=Integer.parseInt(dia);
            numeroMes=Integer.parseInt(mes);
            numeroAnno=Integer.parseInt(anno);
        }catch (Exception e){
            JOptionPane.showMessageDialog(null,"La fecha introducida es incorrecta");
            return false;
        }
        clienteRegistrado=true;
        if (((numeroMes>=1) && (numeroMes<=12)) && ((numeroDia>=1) && (numeroDia<=31)) && ((numeroAnno>=1) && (numeroAnno<=3000))){
            if ((((numeroMes==4)||(numeroMes==6)||(numeroMes==9)||(numeroMes==11))&&(numeroDia<=30))||((numeroMes==2)
                    && (numeroDia<=28))||(numeroMes==1)||(numeroMes==3)||(numeroMes==5)||(numeroMes==7)||(numeroMes==8)||(numeroMes==10)){
                if (serviceCliente.comprobarSiCliente(codigoNIF)){
                    fecha=dia+"/"+mes+"/"+anno;
                    NIF=codigoNIF;
                    return true;
                } else {
                    JOptionPane.showMessageDialog(null,"El código introducido no pertenece a ningún cliente registrado");
                    return false;
                }
            } return true;
        }else {
            JOptionPane.showMessageDialog(null,"La fecha introducida es incorrecta");
            return false;
        }
    }
    public void addCapuccino(){
        String producto = "capuccino";
        if (clienteRegistrado){
            precioProducto= "1,40";
            precioproducto=1.40;            
        }else {
            precioProducto= "1,75";
            precioproducto=1.75; 
        }
        añadirATabla(producto,precioProducto,precioproducto);
    }
    public void addExpresso(){
        String producto = "expresso";
        if (clienteRegistrado){
            precioProducto= "1,00";
            precioproducto=1.00;             
        }else {
            precioProducto= "1,25";
            precioproducto=1.25;
        }añadirATabla(producto,precioProducto,precioproducto);
    }
    public void addLatte(){
        String producto = "latte";
        if (clienteRegistrado){
            precioProducto= "1,20";
            precioproducto=1.20;            
        }else {
            precioProducto= "1,50";
            precioproducto=1.50;
        }añadirATabla(producto,precioProducto,precioproducto);
    }
    public void addChickenSalad(){
        String producto = "ensalada de pollo";
        if (clienteRegistrado){
            precioProducto= "5,00";
            precioproducto=5.00; 
        }else {
            precioProducto= "6,25";
            precioproducto=6.25; 
        }añadirATabla(producto,precioProducto,precioproducto);
    }
    public void addTunaSalad(){
        String producto = "ensalada de atún";
        if (clienteRegistrado){
            precioProducto= "6,00";
            precioproducto=6.00;
        }else {
            precioProducto= "7,50";
            precioproducto=7.50; 
        }añadirATabla(producto,precioProducto,precioproducto);
    }
    public void addChickenSandwich(){
        String producto = "sandwich de pollo";
        if (clienteRegistrado){
            precioProducto= "3,60";
            precioproducto=3.60;
        }else {
            precioProducto= "4,50";
            precioproducto=4.50; 
        }añadirATabla(producto,precioProducto,precioproducto);
    }
    public void addSalmonSandwich(){
        String producto = "sandwich de salmón";
        if (clienteRegistrado){
            precioProducto= "4,00";
            precioproducto=4.00; 
        }else {
            precioProducto= "5,00";
            precioproducto=5.00; 
        }añadirATabla(producto,precioProducto,precioproducto);
    }
    public void añadirATabla (String producto, String precioProducto, double precioproducto){
        Vector filatabla=new Vector();
        ArrayList filapedido=new ArrayList();
        total=total+precioproducto;
        cantidadProductos ++;
        String totalstring=Double.toString(total);
        totalstring=totalstring.replace(".", ",");
        filatabla.add(0,producto);
        filatabla.add(1,precioProducto);
        filatabla.add(2,totalstring);
        tabla.addRow(filatabla);
                
        filapedido.add(0,producto);
        filapedido.add(1,precioProducto);
        filapedido.add(2,totalstring);
        pedido.add(filapedido);
        altaPedido.getTblProductos().setModel(tabla);
        altaPedido.getPanelTabla().setViewportView(altaPedido.getTblProductos());
        altaPedido.getTxtTotal().setText(totalstring);
    }

    public boolean comprobarSiProducto(int indiceFila){
        if (indiceFila<cantidadProductos){
            return true;
        }else {
            return false;
        }
    }
    public void eliminarProducto(int indiceFila,double precioproducto){
        total=total-precioproducto;
        tabla.removeRow(indiceFila);
        pedido.remove(indiceFila);
        String totalstring=Double.toString(total);
        altaPedido.getTxtTotal().setText(totalstring);
    }
    public void imprimirRecibo(){
        try {
            servicePedidos.savePedido(pedido,total,fecha,NIF);
            String textoAmostrar="Se imprime el recibo. El total ha pagar es ";
            textoAmostrar+= total;
            JOptionPane.showMessageDialog(null,textoAmostrar);
        } catch (Exception e){
            JOptionPane.showMessageDialog(null,"Hubo un error al almacenar el pedido");
        }
    }
}
