/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package caja.clientes.acciones;
import caja.clientes.ModificarCliente;
import caja.gestionBD.GestionSQLClientes;
import caja.gestionBD.ServiceCliente;
import java.util.ArrayList;
import javax.swing.JOptionPane;
/**
 *
 * @author pacolavado
 */
public class AccionesModificarCliente {
    private ModificarCliente modificarCliente;
    public ServiceCliente serviceCliente;
    public AccionesModificarCliente (ModificarCliente modificarCliente){
        this.modificarCliente=modificarCliente;
        this.serviceCliente=new ServiceCliente();
    }
    public void mostrarDatosCliente() {
        //***AQUI ES DONDE HAY QUE RECABAR LA INFORMACION A ENVIAR A LA 
        //BASE DE DATOS
        String NIF = modificarCliente.getTxtNIF().getText();
        ArrayList datosCliente = new ArrayList();
        if (serviceCliente.comprobarSiCliente(NIF)){
            try {
                datosCliente=serviceCliente.recabarDatosCliente(NIF);
                // En caso de que se encuentre en la base de datos, se mostrará en
                // las cajas de texto los datos encontrados para poder darlo de baja
                modificarCliente.getTxtNombre().setText(datosCliente.get(0).toString());
                modificarCliente.getTxtPrimerApellido().setText(datosCliente.get(1).toString());
                modificarCliente.getTxtSegundoApellido().setText(datosCliente.get(2).toString());
            }catch (Exception e){
                JOptionPane.showMessageDialog(null, "No se pueden recabar los datos del cliente");
            }
        }
    }    
    public void modificarCliente() {
        //***AQUI ES DONDE HAY QUE RECABAR LA INFORMACION A ENVIAR A LA 
        //BASE DE DATOS
        String NIF = modificarCliente.getTxtNIF().getText();
        String nombre = modificarCliente.getTxtNombre().getText();
        String primerApellido = modificarCliente.getTxtPrimerApellido().getText();
        String segundoApellido = modificarCliente.getTxtSegundoApellido().getText();
        try {
            serviceCliente.updateCliente(NIF, nombre, primerApellido, segundoApellido);
        } catch (Exception e){
            JOptionPane.showMessageDialog(null, "No se pueden modificar los datos del cliente");
        }
    }   
}
