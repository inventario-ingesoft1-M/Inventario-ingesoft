package caja.clientes.acciones;
import caja.clientes.BajaCliente;
import caja.gestionBD.ServiceCliente;
import java.util.ArrayList;
import javax.swing.JOptionPane;
/**
 *
 * @author pacolavado
 */
public class AccionesBajaCliente {
    private BajaCliente bajaCliente;
    public ServiceCliente serviceCliente;
    public AccionesBajaCliente (BajaCliente bajaCliente){
        this.bajaCliente=bajaCliente;
        this.serviceCliente=new ServiceCliente(); 
    }
    public void mostrarDatosCliente() {
        // Array en el que se almacenan el nombre, primer y segundo apellido del
        // cliente en caso de que exista
        ArrayList datosCliente = new ArrayList();
        // Esta función recoge el NIF introducido en la caja de texto
        String NIF = bajaCliente.getTxtNIF().getText();
        // Se buscará si el NIF introducido coincide con alguno de la base de datos 
        if (serviceCliente.comprobarSiCliente(NIF)){
            try {
                datosCliente=serviceCliente.recabarDatosCliente(NIF);
                // En caso de que se encuentre en la base de datos, se mostrará en
                // las cajas de texto los datos encontrados para poder darlo de baja
                bajaCliente.getTxtNombre().setText(datosCliente.get(0).toString());
                bajaCliente.getTxtPrimerApellido().setText(datosCliente.get(1).toString());
                bajaCliente.getTxtSegundoApellido().setText(datosCliente.get(2).toString());
            }catch (Exception e){
            JOptionPane.showMessageDialog(null, "No se pueden recabar los datos del cliente");
            }
        }
    }
    public void bajaCliente() {
        // En caso de que se quiera borrar el cliente de la base de datos
        // se borrarán posibles datos que hubiera en las cajas de texto
        String NIF = bajaCliente.getTxtNIF().getText();
        try {
            serviceCliente.deleteCliente(NIF);
            bajaCliente.getTxtNIF().setText("");
            bajaCliente.getTxtNombre().setText("");
            bajaCliente.getTxtPrimerApellido().setText("");
            bajaCliente.getTxtSegundoApellido().setText("");
        } catch (Exception e){
            JOptionPane.showMessageDialog(null, "No se pueden borrar los datos del cliente");
        }
    }
}
