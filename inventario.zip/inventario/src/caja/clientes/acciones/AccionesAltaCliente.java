package caja.clientes.acciones;
import caja.clientes.AltaCliente;
import caja.gestionBD.ServiceCliente;
import javax.swing.JOptionPane;

public class AccionesAltaCliente {
    // Declaración de variables
    private AltaCliente altaCliente;
    public ServiceCliente serviceCliente;
    // Procedimiento que crea los objetos necesarios
    public AccionesAltaCliente (AltaCliente altaCliente){
        this.altaCliente=altaCliente;
        this.serviceCliente=new ServiceCliente();
    }
    public void altaCliente() {
        // Cuando se pulsa el botón ALTA se procede a obtener los valores
        // introducidos en las cajas de texto
        String NIF = altaCliente.getTxtNIF().getText();
        String nombre = altaCliente.getTxtNombre().getText();
        String primerApellido = altaCliente.getTxtPrimerApellido().getText();
        String segundoApellido = altaCliente.getTxtSegundoApellido().getText();
        // Valores que son pasados a la base de datos
        try {
            serviceCliente.saveCliente(NIF, nombre, primerApellido, segundoApellido);
        } catch (Exception e){
            JOptionPane.showMessageDialog(null, "No se pudo dar de alta los datos del cliente");
        }
    }
}
