/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package caja.principal.acciones;
import inventario.principal.inventario;
/**
 *
 * @author pacolavado
 */
public class Accionesinventario {
    //VARIABLES
    private inventario inventario;
    //METODOS
    public Accionesinventario(inventario inventario){
        this.inventario=inventario;
    }  

}
