package caja.gestionBD;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Iterator;
import javax.swing.JOptionPane;

public class ServicePedidos {
    private GestionSQLPedidos gestionSQL;
    public void savePedido(ArrayList pedido, double total, String fecha, String NIF) {
        // Descomponemos el ArrayList de ArrayList para insertar cada valor individual
        // en las tablas
        gestionSQL=new GestionSQLPedidos();
        String saveDatosPedido="insert into pedidos values (";
        String listadoProductos="";
        String ultimoIdProductos="select * from productos";
        String ultimoIdPedidos="select * from pedidos";
        ArrayList<String> pedidoIndividual;
        Iterator<ArrayList<String>> iterador = pedido.iterator();
        int numeroProducto=0;
        int numeroPedido=0;
        while (iterador.hasNext()){
            String saveDatosProductos="insert into productos values (";
            pedidoIndividual = iterador.next();
            abrirConexion();
            try {
                numeroProducto=gestionSQL.executeSqlRecabarUltimoId (ultimoIdProductos);
                numeroPedido=gestionSQL.executeSqlRecabarUltimoId (ultimoIdPedidos);
                numeroProducto ++;
                saveDatosProductos += "'" + numeroProducto + "'"+",";
                saveDatosProductos += "'" + pedidoIndividual.get(1) + "'"+",";
                saveDatosProductos += "'" + pedidoIndividual.get(0) + "'"+",";
                saveDatosProductos += "'" + numeroPedido + "')";
                gestionSQL.executeSqlSaveDatosPedido (saveDatosProductos);
                listadoProductos +=" "+ pedidoIndividual.get(0)+",";
            }catch (Exception e){
                JOptionPane.showMessageDialog(null, "No se pudo guardar el nuevo cliente");
            }
            cerrarConexion();
        }
        abrirConexion();
        try {
            numeroPedido=gestionSQL.executeSqlRecabarUltimoId (ultimoIdPedidos);
            numeroPedido ++;
            saveDatosPedido += "'" + numeroPedido + "'"+",";
            saveDatosPedido +="'"+fecha+"'"+","+"'"+total+"'"+","+"'"+NIF+"','"+listadoProductos+"')";
            gestionSQL.executeSqlSaveDatosPedido (saveDatosPedido);
        }catch (Exception e){
            JOptionPane.showMessageDialog(null, "No se pudo guardar los datos del pedido");
        }
        cerrarConexion();
    }
    public ResultSet mostrarFechaPedidos(String dia, String mes, String anno){
        gestionSQL=new GestionSQLPedidos();
        ResultSet r = null;
        String consulta = "";
        consulta="select * from pedidos where fecha=";
        consulta +="'"+dia+"/"+mes+"/"+anno+"';";
        abrirConexion();
        try {
            r=gestionSQL.executeSqlFechaPedidos(consulta);
            return r;
        }catch (Exception e){
            JOptionPane.showMessageDialog(null, "No se pudieron recabar los pedidos de la fecha indicada");
        }
        cerrarConexion();
        return r;
    } 
    public ResultSet mostrarPedidosCliente(String NIF){
        gestionSQL=new GestionSQLPedidos();
        ResultSet r = null;
        String consulta = "";
        consulta="select * from pedidos where NIF=";
        consulta +="'"+NIF+"';";
        abrirConexion();
        try {
            r=gestionSQL.executeSqlPedidosCliente(consulta);
            return r;
        }catch (Exception e){
            JOptionPane.showMessageDialog(null,"No se pudieron recabar los pedidos del cliente indicado");
        }
        cerrarConexion();
        return r;
    }
    private void abrirConexion(){
        try {
            gestionSQL.openConnection();
        } catch (Exception e){
            JOptionPane.showMessageDialog(null, "No es posible abrir la conexión con la base de datos");
        }  
    }
    private void cerrarConexion(){
        try {
          gestionSQL.closeConnection();  
        } catch (Exception e){
            JOptionPane.showMessageDialog(null, "No es posible cerrar la conexión");
        }
    }
}
