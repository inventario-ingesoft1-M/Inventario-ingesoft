package caja.gestionBD;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;
import java.util.ArrayList;

public class GestionSQLPedidos {
    Connection conexion;
    Statement sentencia;
    private ServicePedidos servicePedidos;

    public void openConnection(){
        try{
            String controlador="sun.jdbc.odbc.JdbcOdbcDriver";
            Class.forName(controlador).newInstance();
        }catch(Exception e){
            JOptionPane.showMessageDialog(null,"Error al cargar el controlador");
        }try{
            String DSN="jdbc:odbc:Driver={Microsoft Access Driver (*.mdb)};DBQ="+
                    "Base\\HOSTELERIA.MDB";
            String user = "";
            String password="";
            conexion=DriverManager.getConnection(DSN,user,password);
        }catch(Exception e){
            JOptionPane.showMessageDialog(null,"Error al realizar la conexion");
        }try{
            sentencia=conexion.createStatement(
                    ResultSet.TYPE_SCROLL_INSENSITIVE,
                    ResultSet.CONCUR_READ_ONLY);
        }catch(Exception e){
            JOptionPane.showMessageDialog(null,"Error al crear el objeto sentencia");
        }
    }

    void closeConnection() {
        try {
            conexion.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "No se pudo cerrar la base de datos");
        }
    }
    void executeSqlUpdate(String consulta){
        try{
            sentencia.executeUpdate(consulta);
        }catch (Exception e){
            JOptionPane.showMessageDialog(null, "Error al modificar los datos del pedido");
        }
    }  
    void executeSqlSaveDatosPedido (String consulta){
        try {
            sentencia.executeUpdate(consulta);
        }catch (Exception e){
            JOptionPane.showMessageDialog (null, "Se ha producido un error");
        }
    }
    int executeSqlRecabarUltimoId (String ultimoId){
        try {
            ResultSet r=sentencia.executeQuery(ultimoId);
            if (!r.first()){
                return 0;
            } else {
                r.last();
                return r.getInt(1); 
            }
        }catch (Exception e){
            JOptionPane.showMessageDialog (null, "No se ha captado el numero correcto");
            return 3;
        }
    }   
    ResultSet executeSqlFechaPedidos (String consulta){
        ResultSet r = null;
        try{
            r=sentencia.executeQuery(consulta);
            return r;
        }catch (Exception e){
            JOptionPane.showMessageDialog(null, "Error al obtener los pedidos en la fecha indicada");
            return r;
        }
    }
    ResultSet executeSqlPedidosCliente (String consulta){
        ResultSet r = null;
        try{
            r=sentencia.executeQuery(consulta);
            return r;
        }catch (Exception e){
            JOptionPane.showMessageDialog(null, "Error al obtener los pedidos del cliente indicado");
            return r;
        }
    }
}
