package caja.gestionBD;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;
import java.util.ArrayList;

public class GestionSQLClientes {
    Connection conexion;
    Statement sentencia;
    private ServiceCliente serviceCliente;

    public void openConnection(){
        try{
            String controlador="sun.jdbc.odbc.JdbcOdbcDriver";
            Class.forName(controlador).newInstance();
        }catch(Exception e){
            JOptionPane.showMessageDialog(null,"Error al cargar el controlador");
        }try{
            String DSN="jdbc:odbc:Driver={Microsoft Access Driver (*.mdb)};DBQ="+
                    "Base\\HOSTELERIA.MDB";
            String user = "";
            String password="";
            conexion=DriverManager.getConnection(DSN,user,password);
        }catch(Exception e){
            JOptionPane.showMessageDialog(null,"Error al realizar la conexion");
        }try{
            sentencia=conexion.createStatement(
                    ResultSet.TYPE_SCROLL_INSENSITIVE,
                    ResultSet.CONCUR_READ_ONLY);
        }catch(Exception e){
            JOptionPane.showMessageDialog(null,"Error al crear el objeto sentencia");
        }
    }

    void closeConnection() {
        try {
            conexion.close();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "No se pudo cerrar la base de datos");
        }
    }

    void executeSqlSave(String consulta) {
        try {
            sentencia.executeUpdate(consulta);
            JOptionPane.showMessageDialog(null,"Se ha dado de alta al cliente correctamente");
        }catch (Exception e){
            JOptionPane.showMessageDialog(null, "Error al introducir el nuevo cliente");
        }
    }
    void executeSqlDelete(String consulta){
        try{
            sentencia.executeUpdate(consulta);
            JOptionPane.showMessageDialog(null, "Se ha dado de baja al cliente correctamente");
        }catch (Exception e){
            JOptionPane.showMessageDialog(null, "Error al borrar el cliente. Compruebe que realmente existe");
        }
    }
    void executeSqlUpdate(String consulta){
        try{
            sentencia.executeUpdate(consulta);
            JOptionPane.showMessageDialog(null,"Se han modificado los datos del cliente correctamente");
        }catch (Exception e){
            JOptionPane.showMessageDialog(null, "Error al modificar los datos del cliente");
        }
    }  
    ArrayList executeSqlRecabarDatosCliente(String consulta){
        this.serviceCliente=new ServiceCliente();
        ArrayList datosCliente=new ArrayList();
        try{
            ResultSet r=sentencia.executeQuery(consulta);
            if (!r.first()){
                JOptionPane.showMessageDialog(null,"No existe ningún cliente con ese NIF");
                datosCliente.add("No existe");
                datosCliente.add("No existe");
                datosCliente.add("No existe");
                return datosCliente; 
           }else {
                datosCliente.add(r.getString("nombre"));
                datosCliente.add(r.getString("primerApellido"));
                datosCliente.add(r.getString("segundoApellido"));
                return datosCliente;
            }
        }catch (Exception e){
            JOptionPane.showMessageDialog(null, "Error al modificar el cliente. Compruebe que realmente existe");
            datosCliente.add("error");
            datosCliente.add("error");
            datosCliente.add("error");
            return datosCliente;
        }
    }    
    boolean executeSqlComprobarSiCliente (String consulta){
        try{
            ResultSet r=sentencia.executeQuery(consulta);
            if (!r.first()){
                return false;
            } else {
                return true;
            }
        }catch (Exception e){
            JOptionPane.showMessageDialog(null, "Error al comprobar si el cliente indicado existe");
            return false;
        }
    }
}
