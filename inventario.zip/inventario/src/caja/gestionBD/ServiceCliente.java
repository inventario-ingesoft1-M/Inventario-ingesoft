package caja.gestionBD;
import javax.swing.JOptionPane;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Vector;
/**
 *
 * @author pacolavado
 */
public class ServiceCliente {
    private GestionSQLClientes gestionSQL;
    public void saveCliente(String NIF, String nombre, String primerApellido, String segundoApellido) {
        String consulta = "";
        gestionSQL=new GestionSQLClientes();
        consulta = "insert into clientes values (";
        consulta += "'" + NIF + "'"+",";
        consulta += "'" + nombre + "'"+",";
        consulta += "'" + primerApellido + "'"+",";
        consulta += "'" + segundoApellido + "')";
        abrirConexion();
        try {
            gestionSQL.executeSqlSave(consulta);
        }catch (Exception e){
            JOptionPane.showMessageDialog(null, "No es posible guardar los datos del cliente");
        }
        cerrarConexion();
    }    
    public void deleteCliente(String NIF) {
        gestionSQL=new GestionSQLClientes();
        String consulta = "";
        consulta = "delete from clientes where NIF =";
        consulta += "'" + NIF + "';";
        abrirConexion();       
        try {
            gestionSQL.executeSqlDelete(consulta);
        }catch (Exception e){
            JOptionPane.showMessageDialog(null, "No es posible borrar los datos del cliente");
        }
        cerrarConexion();
    }
    public void updateCliente(String NIF, String nombre, String primerApellido,String segundoApellido) {
        String consulta = "";
        gestionSQL=new GestionSQLClientes();
        abrirConexion();
        consulta = "update clientes set nombre =";
        consulta += "'" + nombre + "', primerApellido=";
        consulta += "'" + primerApellido + "', segundoApellido=";
        consulta += "'" + segundoApellido + "' where NIF=";
        consulta += "'" + NIF + "';";
        try {
            gestionSQL.executeSqlUpdate(consulta);
        }catch (Exception e){
            JOptionPane.showMessageDialog(null,"No es posible modificar los datos del cliente");
        }
        cerrarConexion();
    }    
    public ArrayList recabarDatosCliente(String NIF) {
        String consulta = "";
        ArrayList datosCliente=new ArrayList();
        gestionSQL=new GestionSQLClientes();
        abrirConexion();
        consulta = "select * from clientes where NIF=";
        consulta += "'" + NIF + "'";
        try {
            datosCliente=gestionSQL.executeSqlRecabarDatosCliente(consulta);
        }catch (Exception e){
            JOptionPane.showMessageDialog(null, "No es posible recabar los datos del cliente");
        }
        cerrarConexion();
        return datosCliente;
    }    
    public boolean comprobarSiCliente(String NIF){
        String comprobar="select * from clientes where NIF=";
        comprobar +="'"+NIF+"';";
        boolean flag=false;
        gestionSQL=new GestionSQLClientes();
        abrirConexion();
        try {
            flag=gestionSQL.executeSqlComprobarSiCliente(comprobar);
        }catch (Exception e){
            JOptionPane.showMessageDialog(null,"No se pudo comprobar si existe el cliente");
        }
        cerrarConexion();
        return flag;
    }
    private void abrirConexion(){
        try {
            gestionSQL.openConnection();
        } catch (Exception e){
            JOptionPane.showMessageDialog(null, "No es posible abrir la conexión con la base de datos");
        }  
    }
    private void cerrarConexion(){
        try {
          gestionSQL.closeConnection();  
        } catch (Exception e){
            JOptionPane.showMessageDialog(null, "No es posible cerrar la conexión");
        }
    }
}
